package Package;

import java.net.MalformedURLException;
import java.net.URL;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;


public class CalculadoraTeste {

	@Test
	public void somaDoisvalores() throws MalformedURLException {
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
	    desiredCapabilities.setCapability("platformName", "Android");
	    desiredCapabilities.setCapability("appium:deviceName", "emulator");
	    desiredCapabilities.setCapability("appium:automationName", "uiautomator2");
	    desiredCapabilities.setCapability("appium:appPackage", "com.google.android.calculator");
	    desiredCapabilities.setCapability("appium:appActivity", "com.android.calculator2.Calculator");
	    desiredCapabilities.setCapability("appium:ensureWebviewsHavePages", true);
	    desiredCapabilities.setCapability("appium:nativeWebScreenshot", true);
	    desiredCapabilities.setCapability("appium:newCommandTimeout", 3600);
	    desiredCapabilities.setCapability("appium:connectHardwareKeyboard", true);
	    
	    AndroidDriver<MobileElement> driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), desiredCapabilities);

	    
	    MobileElement el1 = (MobileElement) driver.findElementByAccessibilityId("1");
	    el1.click();
	    MobileElement el2 = (MobileElement) driver.findElementByAccessibilityId("0");
	    el2.click();
	    MobileElement el3 = (MobileElement) driver.findElementByAccessibilityId("plus");
	    el3.click();
	    MobileElement el4 = (MobileElement) driver.findElementByAccessibilityId("2");
	    el4.click();
	    MobileElement el5 = (MobileElement) driver.findElementByAccessibilityId("0");
	    el5.click();
	    MobileElement el6 = (MobileElement) driver.findElementByAccessibilityId("equals");
	    el6.click();
	    MobileElement el7 = (MobileElement) driver.findElementById("com.google.android.calculator:id/result_final");
	    el7.click();
 	    System.out.println(el7.getText());
	    Assert.assertEquals("30", el7.getText());
	    
	    driver.quit();
	    
	}
	
}
